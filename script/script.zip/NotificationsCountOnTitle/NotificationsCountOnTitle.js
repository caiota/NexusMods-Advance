let BASE_TITLE = document.title;

function NOTIFICATION_COUNT_TO_TITLE() {
    if(BASE_TITLE.indexOf(") ")==-1){
        BASE_TITLE = document.title
    }
  const el = document.querySelector("span[data-e2eid='unread-message-count']");
  if (!el) {
    setTimeout(NOTIFICATION_COUNT_TO_TITLE, 5000);
    return;
  }

  const not_count = parseInt(
    el.innerText.replace("UNREAD NOTIFICATIONS", "").trim()
  );

  if (not_count && not_count > 0) {
    document.title = `(${not_count}) ${BASE_TITLE}`;
  } else {
    document.title = BASE_TITLE;
  }

  setTimeout(NOTIFICATION_COUNT_TO_TITLE, 5000);
}
