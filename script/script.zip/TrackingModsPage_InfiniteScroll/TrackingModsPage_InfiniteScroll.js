async function GENERATE_INFINITE_SCROLL_TRACKCENTRE() {
console.log("Tracking Centre Infinite Scroll not made YET")

}