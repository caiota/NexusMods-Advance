async function APPLY_STRETCH_IMAGES(){
    
}